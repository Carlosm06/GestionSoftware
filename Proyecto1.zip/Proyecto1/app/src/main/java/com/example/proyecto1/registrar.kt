package com.example.proyecto1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.proyecto1.databinding.ActivityMainBinding
import com.example.proyecto1.databinding.ActivityRegistrarBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class registrar : AppCompatActivity() {

    private lateinit var binding: ActivityRegistrarBinding
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistrarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        var db = FirebaseDatabase.getInstance().getReference("Crud")

        binding.ButtonRegistrar.setOnClickListener {
            val Nombre = binding.NombreRegistro.text.toString()
            val Apellido = binding.ApellidoRegistro.text.toString()
            val Correo = binding.CorreoRegistro.text.toString()
            val Sexo = binding.SexoRegistro.text.toString()
            val Contrasena = binding.ContrasenaRegistro.text.toString()
            val Direccion = binding.DireccionRegistro.text.toString()
            val Nacimiento = binding.NacimientoRegistro.text.toString()
            val Telefono = binding.TelefonoRegistro.text.toString()
            val Pais = binding.PaisRegistro.text.toString()
            val Provincia = binding.ProvinciaRegistro.text.toString()


            val Datos = RegistroUsuario(
                Nombre,
                Apellido,
                Telefono,
                Correo,
                Sexo,
                Nacimiento,
                Pais,
                Provincia,
                Direccion,
                Contrasena
            )
            db.child(Nombre).setValue(Datos).addOnSuccessListener {

              binding.NombreRegistro.text.clear()
              binding.ApellidoRegistro.text.clear()
              binding.CorreoRegistro.text.clear()
              binding.SexoRegistro.text.clear()
              binding.ContrasenaRegistro.text.clear()
              binding.DireccionRegistro.text.clear()
              binding.NacimientoRegistro.text.clear()
              binding.TelefonoRegistro.text.clear()
              binding.PaisRegistro.text.clear()
              binding.ProvinciaRegistro.text.clear()

                Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show()
            }.addOnFailureListener {
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show()
            }
            signUpUser()
        }


    }

    private fun signUpUser() {
        val email = binding.CorreoRegistro.text.toString()

        val pass = binding.ContrasenaRegistro.text.toString()



        if (email.isBlank() || pass.isBlank()) {

            Toast.makeText(this, "Rellene los Campos Requeridos", Toast.LENGTH_SHORT).show()

            return

        }
        auth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(this) {

            if (it.isSuccessful) {

                Toast.makeText(this, "Bienvenido", Toast.LENGTH_SHORT).show()
                val intent2 = Intent(this, Login::class.java)

                startActivity(intent2)


            } else {

                Toast.makeText(this, "Vuelva a intentar!", Toast.LENGTH_SHORT).show()

            }


        }
    }
}
