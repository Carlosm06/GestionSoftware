package com.example.proyecto1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.proyecto1.databinding.ActivityUsuarioBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class Usuario : AppCompatActivity() {
    private lateinit var binding: ActivityUsuarioBinding
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        var db = FirebaseDatabase.getInstance().getReference("Crud")

        binding.buttonUsuario.setOnClickListener {

            val nombreusuario: String = binding.TextMostrarUsuario.toString()
            if (nombreusuario.isNotEmpty()) {
                readData(nombreusuario)
            } else {
                Toast.makeText(this, "Introduzca el Nombre", Toast.LENGTH_SHORT).show()
            }


        }
    }

    private fun readData(nombreusuario: String) {
        database= FirebaseDatabase.getInstance().getReference("Crud")
        database.child(nombreusuario).get().addOnSuccessListener {
            if(it.exists()){
                val nombre = it.child("nombre").value
                val apellido = it.child("apellido").value
                val correo = it.child("correo").value
                val fecha = it.child("nacimiento").value
                val pais = it.child("pais").value
                val sexo= it.child("sexo").value
                val telefono = it.child("telefono").value
                val direccion = it.child("direccion").value
                val provincia = it.child("provincia").value

                Toast.makeText(this, "Extraccion", Toast.LENGTH_SHORT).show()
                binding.TextMostrarUsuario.text.clear()

                binding.TextUsuarioNombre.text = nombre.toString()
                binding.TextUsuarioApellido.text= apellido.toString()
                binding.TextUsuarioCorreo.text= correo.toString()
                binding.TextUsuarioFecha.text= fecha.toString()
                binding.TextUsuarioPais.text= pais.toString()
                binding.TextUsuarioSexo.text= sexo.toString()
                binding.TextUsuarioTelefono.text= telefono.toString()
                binding.TextUsuarioDireccion.text= direccion.toString()
                binding.TextUsuarioProvincia.text= provincia.toString()

        } else{
                Toast.makeText(this, "Usuario no Existente", Toast.LENGTH_SHORT).show()
            }
        }.addOnFailureListener {
            Toast.makeText(this, "Fallido", Toast.LENGTH_SHORT).show()
        }
    }
}
