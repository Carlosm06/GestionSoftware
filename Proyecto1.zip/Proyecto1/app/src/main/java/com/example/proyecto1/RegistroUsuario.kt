package com.example.proyecto1

data class RegistroUsuario(val Nombre : String?= null, val Apellido: String?= null, val Telefono : String?= null, val Correo : String?= null, val Sexo: String?= null, val Nacimiento: String?= null, val Pais: String?= null, val Provincia: String?= null, val Direccion: String?= null, val Contrasena: String?= null){

}
