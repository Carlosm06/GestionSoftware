package com.example.proyecto1

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import com.example.proyecto1.databinding.ActivityMainBinding
import com.example.proyecto1.databinding.ActivityRegistrarBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference

class Login : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth= FirebaseAuth.getInstance()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.TextLoginRegistrar.setOnClickListener {
            val intent3 = Intent(this,registrar::class.java)
            startActivity(intent3)

         binding= ActivityMainBinding.inflate(layoutInflater)
         setContentView(binding.root)

         binding.TextLoginRecuperar.setOnClickListener {
             val intent4 = Intent(this,Recuperacion::class.java)
             startActivity(intent4)

         binding.ButtonLogin.setOnClickListener {
             val intent5 = Intent(this, Usuario::class.java)
             startActivity(intent5)
         }

         }
        }
    }
    private fun login() {


        val email = binding.TextLoginCorreo.text.toString()

        val pass = binding.TextLoginContraseA.text.toString()

        if (email.isBlank() || pass.isBlank()) {

            Toast.makeText(this, "Email and Password can't be blank", Toast.LENGTH_SHORT).show()
            return

        }
        auth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(this) {


            if (it.isSuccessful) {


                val intent2 = Intent(this, Usuario::class.java)
                startActivity(intent2)

                Toast.makeText(this, "Successfully LoggedIn", Toast.LENGTH_SHORT).show()

            } else

                Toast.makeText(this, "Log In failed ", Toast.LENGTH_SHORT).show()
        }
    }

}